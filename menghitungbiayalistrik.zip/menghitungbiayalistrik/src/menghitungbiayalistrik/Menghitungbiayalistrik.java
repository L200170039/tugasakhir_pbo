/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menghitungbiayalistrik;

/**
 *
 * @author nubzero
 */
public class Menghitungbiayalistrik {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        frame_menghitungbiayalistrik Laund = new frame_menghitungbiayalistrik();
        Laund.setVisible(true);
    }
    
}
